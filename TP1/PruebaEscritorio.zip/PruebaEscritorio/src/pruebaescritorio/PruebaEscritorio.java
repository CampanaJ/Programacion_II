/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pruebaescritorio;

/**
 *
 * @author Usuario
 */

public class PruebaEscritorio {
    public static void main(String[] args) {
        int a = 5;
        int b = 2;
        int resultado = a / b;  // División entera → 2

        System.out.println("Resultado: " + resultado);
    }
}
