/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package expresionesinstrucciones;

/**
 *
 * @author Usuario
 */
public class ExpresionesInstrucciones {
    public static void main(String[] args) {
        int x = 10;          // Instrucción con expresión
        x = x + 5;           // Instrucción con expresión
        System.out.println(x); // Instrucción
    }
}
