/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package conversiones;

/**
 *
 * @author Usuario
 */

import java.util.Scanner;

public class Conversiones {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingresa el primer número: ");
        int a = scanner.nextInt();

        System.out.print("Ingresa el segundo número: ");
        int b = scanner.nextInt();

        // División con enteros
        System.out.println("División int: " + (a / b));

        // División con decimales
        double da = a;
        double db = b;
        System.out.println("División double: " + (da / db));
    }
}
